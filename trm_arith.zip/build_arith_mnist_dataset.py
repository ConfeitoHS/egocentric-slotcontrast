import os
from argparse import ArgumentParser
from itertools import product
import numpy as np

primitive_ops = ['add', 'sub', 'min', 'max']
min_value = 27
mask_idx = 28
pad_idx = 29


def get_op(name):
    if name == 'add':
        return np.add
    elif name == 'sub':
        return np.subtract
    elif name == 'min':
        return min
    elif name == 'max':
        return max
    else:
        raise ValueError


def create_op_data(op_name, sample_size, num_examples):
    op1, op2 = op_name.split('_')
    op1 = get_op(op1) if len(op1) else None
    op2 = get_op(op2) if len(op2) else None

    n_num = 3 if op1 is not None and op2 is not None else 2

    pad = np.array([pad_idx])

    # 최종 데이터 행렬과 정답 벡터 초기화
    inputs = np.zeros((sample_size, num_examples + 1, 4))
    labels = np.zeros(sample_size)
    for i in range(sample_size):
        # n개의 예제 생성
        for j in range(num_examples):
            # -9 ~ 9 사이의 정수 2 or 3개를 무작위로 생성
            nums = np.random.randint(-9, 10, size=n_num)

            # 선택된 연산 규칙에 따라 정답 계산
            if n_num == 2:
                binary_op = op1 or op2
                answer = binary_op(nums[0], nums[1])

            else:
                intermediate = op1(nums[0], nums[1])

                answer = op2(intermediate, nums[2])

            if n_num == 2:
                if op2 is None:
                    nums = np.concatenate([nums, pad])
                else:
                    nums = np.concatenate([pad, nums])

            inputs[i, j, :-1] = nums
            inputs[i, j, -1] = answer

        # 1개의 쿼리 생성
        query_nums = np.random.randint(-9, 10, size=n_num)

        # 쿼리 문제에 대한 정답 계산
        if n_num == 2:
            binary_op = op1 or op2
            query_answer = binary_op(query_nums[0], query_nums[1])

        else:
            query_intermediate = op1(query_nums[0], query_nums[1])

            query_answer = op2(query_intermediate, query_nums[2])

        if n_num == 2:
            if op2 is None:
                query_nums = np.concatenate([query_nums, pad])
            else:
                query_nums = np.concatenate([pad, query_nums])

        inputs[i, -1, :-1] = query_nums
        # mask token for target
        inputs[i, -1, -1] = mask_idx

        labels[i] = query_answer

    return inputs, labels


def create_symbolic_dataset(split, sample_size, num_examples, output_dir):
    ops_combs = [f'{op1}_{op2}' for op1, op2 in product(primitive_ops, repeat=2)]

    ops_combs += [f'{op}_' for op in primitive_ops]
    ops_combs += [f'_{op}' for op in primitive_ops]

    data = dict()

    for op_comb in ops_combs:
        X, y = create_op_data(op_comb, sample_size, num_examples)

        data[op_comb] = (X + min_value, y + min_value)

    print(f"Save {sample_size} {split} data to {output_dir}")

    np.save(os.path.join(args.output_dir, f"{split}_data.npy"), data)


if __name__ == "__main__":
    parser = ArgumentParser()

    parser.add_argument('--num_train', type=int, default=20000)
    parser.add_argument('--num_val', type=int, default=5000)
    parser.add_argument('--num_test', type=int, default=5000)
    parser.add_argument('--num_examples', type=int, default=4)
    parser.add_argument('--output_dir', type=str, default="data/oracle-arith-mnist/4shots/")

    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    create_symbolic_dataset("train", args.num_train, args.num_examples, args.output_dir)
    create_symbolic_dataset("val", args.num_val, args.num_examples, args.output_dir)
    create_symbolic_dataset("test", args.num_test, args.num_examples, args.output_dir)
