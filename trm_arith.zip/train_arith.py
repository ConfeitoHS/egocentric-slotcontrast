from typing import List
from dataclasses import dataclass
from collections import defaultdict
from copy import deepcopy
import torch
from torch.utils.data import DataLoader
from torch.optim import AdamW
from transformers import get_cosine_with_min_lr_schedule_with_warmup
from experimental_datasets import PuzzleDatasetConfig, ReasoningDataset
from models.trm.model import TinyRecursionModelConfig, TinyRecursionModel, ACTLossHead
from training_utils import EMAHelper


@dataclass
class TRMConfig:
    # data
    dataset_paths: List[str]

    # model
    num_layers: int = 2
    H_cycles: int = 3
    L_cycles: int = 6
    hidden_size: int = 512
    num_heads: int = 8
    expansion: float = 4
    pos_encodings: str = 'rope'
    halt_max_steps: int = 4
    halt_exploration_prob: float = 0.1
    mlp_t: bool = False

    # training
    epochs: int = 250
    eval_interval: int = None
    lr: float = 3e-4
    lr_min_ratio: float = 1.0
    lr_warmup_steps: int = 2000
    weight_decay: float = 0.1
    beta1: float = 0.9
    beta2: float = 0.95
    ema: bool = True
    ema_rate: float = 0.99

    # misc
    seed: int = 42
    global_batch_size: int = 768
    rank: int = 0
    world_size: int = 1
    device: str = 'mps'


def get_dataloader(cfg, split):
    if split == 'train':
        epochs_per_iter = cfg.eval_interval if cfg.eval_interval is not None else cfg.epochs
    elif split == 'test':
        epochs_per_iter = 1
    else:
        raise ValueError

    dataset_cfg = PuzzleDatasetConfig(seed=cfg.seed,
                                      dataset_paths=cfg.dataset_paths,
                                      global_batch_size=cfg.global_batch_size,
                                      test_set_mode=True if split == 'test' else False,
                                      epochs_per_iter=epochs_per_iter,
                                      rank=cfg.rank,
                                      num_replicas=cfg.world_size)

    dataset = ReasoningDataset(dataset_cfg, split)

    dataloader = DataLoader(
        dataset,
        batch_size=None,
        num_workers=1,
        prefetch_factor=8,
        pin_memory=True,
        persistent_workers=True
    )

    return dataloader, dataset.metadata


def get_model(cfg, metadata, device):
    model_cfg = TinyRecursionModelConfig(batch_size=cfg.global_batch_size,
                                         seq_len=metadata.seq_len,  # 9x9 sudoku = 81
                                         num_puzzle_identifiers=metadata.num_puzzle_identifiers,
                                         vocab_size=metadata.vocab_size,
                                         num_layers=cfg.num_layers,
                                         H_cycles=cfg.H_cycles,
                                         L_cycles=cfg.L_cycles,
                                         hidden_size=cfg.hidden_size,
                                         expansion=cfg.expansion,
                                         num_heads=cfg.num_heads,
                                         pos_encodings=cfg.pos_encodings,
                                         halt_max_steps=cfg.halt_max_steps,
                                         halt_exploration_prob=cfg.halt_exploration_prob,
                                         mlp_t=cfg.mlp_t)

    model = ACTLossHead(TinyRecursionModel(model_cfg))

    model = model.to(device=device)

    # model = torch.compile(model)

    return model


def train_batch(cfg, model, batch, optimizer, scheduler, global_batch_size, device, carry=None):
    model.train()

    batch = {k: v.to(device=device) for k, v in batch.items()}

    if carry is None:
        with device:
            carry = model.initial_carry(batch)

    total_metrics = defaultdict(float)
    # step = 0.0
    # while True:
    #     step += 1
    #
    #     model.zero_grad()
    #
    #     carry, loss, metrics, _, all_finish = model(carry=carry, batch=batch, return_keys=[])
    #
    #     ((1 / global_batch_size) * loss).backward()
    #
    #     optimizer.step()
    #     optimizer.zero_grad()
    #
    #     for k, v in metrics.items():
    #         total_metrics[k] += v.item()
    #
    #     if all_finish or step >= cfg.halt_max_steps:
    #         break
    step = 1.0
    model.zero_grad()
    new_carry, loss, metrics, _, _ = model(carry=carry, batch=batch, return_keys=[])

    ((1 / global_batch_size) * loss).backward()

    optimizer.step()
    scheduler.step()

    optimizer.zero_grad()

    for k, v in metrics.items():
        total_metrics[k] += v.item()

    for k, v in total_metrics.items():
        total_metrics[k] = v / step

    return total_metrics, new_carry


def evaluate(model, val_dataloader, device):
    model.eval()

    with torch.no_grad():
        total_metrics = defaultdict(float)

        for set_name, batch, global_batch_size in val_dataloader:
            batch = {k: v.to(device=device) for k, v in batch.items()}

            with device:
                carry = model.initial_carry(batch)

            inference_steps = 0
            while True:
                inference_steps += 1

                carry, loss, metrics, preds, all_finish = model(carry=carry, batch=batch, return_keys=[])

                for k, v in metrics.items():
                    total_metrics[k] += v.item()

                if all_finish:
                    break

        print('[Test] ', total_metrics)


def train_trm():
    cfg = TRMConfig(dataset_paths=["data/oracle-arith-mnist/4shots"],
                    eval_interval=10)

    train_dataloader, metadata = get_dataloader(cfg, 'train')
    val_dataloader, _ = get_dataloader(cfg, 'test')

    training_steps = int(cfg.epochs * metadata.total_groups * metadata.mean_puzzle_examples / cfg.global_batch_size)
    train_epochs_per_iter = cfg.eval_interval if cfg.eval_interval is not None else cfg.epochs
    total_iters = cfg.epochs // train_epochs_per_iter

    device = torch.device(f'{cfg.device}:0')

    model = get_model(cfg, metadata, device)

    print(model)

    ema_helper = None
    if cfg.ema:
        ema_helper = EMAHelper(mu=cfg.ema_rate)
        ema_helper.register(model)

    optimizer = AdamW(model.parameters(),
                      lr=cfg.lr,
                      betas=(cfg.beta1, cfg.beta2),
                      weight_decay=cfg.weight_decay)

    scheduler = get_cosine_with_min_lr_schedule_with_warmup(optimizer,
                                                            num_warmup_steps=cfg.lr_warmup_steps,
                                                            num_training_steps=training_steps,
                                                            min_lr_rate=cfg.lr_min_ratio)

    carry = None
    global_step = 0
    for iter_id in range(total_iters):
        for set_name, batch, global_batch_size in train_dataloader:
            global_step += 1

            train_metrics, carry = train_batch(cfg, model, batch, optimizer, scheduler, global_batch_size, device, carry)

            if ema_helper is not None:
                ema_helper.update(model)

            if global_step % 10 == 0:
                print(train_metrics)

        if ema_helper is not None:
            eval_model = ema_helper.ema_copy(deepcopy(model))
        else:
            eval_model = model

        evaluate(eval_model, val_dataloader, device)

        if ema_helper is not None:
            del eval_model


if __name__ == "__main__":
    train_trm()
